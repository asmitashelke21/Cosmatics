package com.symbiosis.beautycare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeautycareApplicationTests {

	@Test
	void contextLoads() {
	}

}
