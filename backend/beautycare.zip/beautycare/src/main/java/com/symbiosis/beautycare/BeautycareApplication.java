package com.symbiosis.beautycare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeautycareApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeautycareApplication.class, args);
	}

}
